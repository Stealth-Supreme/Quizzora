
# Quizzora - Phase 17 and 18

Added:
- Badge system on the result screen
- Badge chips based on performance milestones
- Celebration overlay for perfect full unlock runs
- More rewarding result feedback
- Keeps the phase 15/16 cinematic reveal and dashboard

Badges include:
- FIRST NODE
- MIDWAY CONTROL
- STABLE HAND
- ELITE OPERATOR
- FULL SYSTEM MASTER

Celebration:
- Only triggers on a perfect run with no failures
- Uses a glowing AI-core overlay and success sound
