const UI = (() => {
  const app = document.getElementById("app");
  const terminal = document.getElementById("terminal");
  const TERMINAL_PREFIX = "Adavya>";
  const terminalHistory = [];
  let typewriterTimer = null;
  let currentLoadingTimer = null;
  const endingTimers = new Set();
  let booted = false;

  const styleQueue = [
    "./css/stage-01-theme.css",
    "./css/stage-02-layout.css",
    "./css/stage-03-shell.css",
    "./css/stage-04-cards.css",
    "./css/stage-05-motion.css",
    "./css/stage-06-hud.css",
    "./css/stage-07-micro.css",
    "./css/stage-07-terminal-log.css",
    "./css/stage-08-sound.css",
    "./css/stage-09-scan.css",
    "./css/stage-10-progress.css",
    "./css/stage-11-question-reveal.css",
    "./css/stage-12-feedback.css",
    "./css/stage-13-results.css",
    "./css/stage-14-badge.css",
    "./css/stage-15-polish.css",
    "./css/stage-16-celebration.css",
    "./css/stage-17-extended.css",
    "./css/stage-18-scan-lines.css",
    "./css/stage-19-ranking.css",
    "./css/stage-20-ending.css"
  ];

  function normalize(value) {
    return String(value ?? "").trim().toLowerCase();
  }

  function escapeHtml(value) {
    return String(value ?? "").replace(/[&<>"']/g, (char) => ({
      "&": "&amp;",
      "<": "&lt;",
      ">": "&gt;",
      '"': "&quot;",
      "'": "&#39;"
    })[char]);
  }

  function injectStyleOnce(id, href) {
    if (document.getElementById(id)) return;
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.id = id;
    link.href = href;
    document.head.appendChild(link);
  }

  function bootStyles() {
    if (booted) return;
    styleQueue.forEach((href, index) => injectStyleOnce(`quizzora-style-${index + 1}`, href));
    booted = true;
  }

  function cancelTimers() {
    if (typewriterTimer) {
      clearInterval(typewriterTimer);
      typewriterTimer = null;
    }
    if (currentLoadingTimer) {
      clearTimeout(currentLoadingTimer);
      currentLoadingTimer = null;
    }
    for (const timer of endingTimers) clearTimeout(timer);
    endingTimers.clear();
  }

  function resetEffects() {
    cancelTimers();
    document.querySelectorAll(".celebration-overlay, .reactor-overlay").forEach((node) => node.remove());
    document.body.classList.remove("ending-active");
    if (document.body.dataset.mode === "ending") {
      document.body.dataset.mode = "idle";
    }
  }

  function setTerminal(text) {
    if (!terminal) return;
    const msg = String(text ?? "").trim();
    if (msg) {
      terminalHistory.push(msg);
      while (terminalHistory.length > 5) terminalHistory.shift();
    }
    terminal.textContent = `${TERMINAL_PREFIX} ${terminalHistory.join(" | ")}`;
  }

  function speak(text, options = {}) {
    if (window.QUIZ_VOICE && typeof window.QUIZ_VOICE.speak === "function") {
      return window.QUIZ_VOICE.speak(text, options);
    }
    return Promise.resolve("unavailable");
  }

  function setStartVisible(visible) {
    const startBtn = document.getElementById("startBtn");
    if (startBtn) startBtn.hidden = !visible;
  }

  function typewriterText(target, text, onDone, speed = 20) {
    const chars = String(text ?? "");
    let index = 0;
    if (typewriterTimer) {
      clearInterval(typewriterTimer);
      typewriterTimer = null;
    }
    target.textContent = "";
    target.classList.add("typing");

    const tickEvery = 2;
    typewriterTimer = setInterval(() => {
      target.textContent += chars.charAt(index);
      if (index % tickEvery === 0 && window.QUIZ_SOUNDS?.typingTick) {
        window.QUIZ_SOUNDS.typingTick();
      }
      index += 1;
      if (index >= chars.length) {
        clearInterval(typewriterTimer);
        typewriterTimer = null;
        target.classList.remove("typing");
        if (typeof onDone === "function") onDone();
      }
    }, speed);
  }

  function renderHud(state, total, activeFeature = "standby") {
    const nextNode = `${Math.min(state.index + 1, total)}/${total}`;
    const unlockedCount = state.unlocked.length;
    const systemState = state.completed ? (state.hadFailure ? "PARTIAL" : "COMPLETE") : "ONLINE";
    return `
      <div class="hud-strip" aria-label="System HUD">
        <div><span class="hud-label">System</span><span class="hud-value">${escapeHtml(systemState)}</span></div>
        <div><span class="hud-label">Node</span><span class="hud-value">${escapeHtml(nextNode)}</span></div>
        <div><span class="hud-label">Score</span><span class="hud-value">${escapeHtml(state.score)}</span></div>
        <div><span class="hud-label">Unlocked</span><span class="hud-value">${escapeHtml(`${unlockedCount}/${total}`)}</span></div>
        <div><span class="hud-label">Next</span><span class="hud-value">${escapeHtml(activeFeature)}</span></div>
      </div>
    `;
  }

  function renderShell(state, total) {
    resetEffects();
    bootStyles();
    document.body.dataset.mode = "idle";
    document.body.dataset.stage = "boot";

    app.innerHTML = `
      <main class="shell landing-shell">
        <section class="frame">
          <aside class="side-rail">
            <div class="rail-card active">
              <div class="rail-label">System</div>
              <div class="rail-value">Idle</div>
            </div>
            <div class="rail-card">
              <div class="rail-label">Mode</div>
              <div class="rail-value">Voice gate</div>
            </div>
            <div class="rail-card">
              <div class="rail-label">Unlock</div>
              <div class="rail-value">Q1</div>
            </div>
          </aside>

          <section class="main-stage">
            <div class="os-chrome">
              <span class="dot red"></span>
              <span class="dot yellow"></span>
              <span class="dot green"></span>
              <span class="machine-id">QUIZZORA OS // CONTROL SHELL</span>
            </div>

            <div class="panel raw-panel">
              <div class="micro-head">Quizzora</div>
              <h1 class="patience-heading">Have patience.</h1>
              <p>Interface begins raw. Correct answers unlock the visual layers step by step.</p>
              <p class="micro-line">Rules must be spoken before start.</p>
              <div class="mini-row">
                <span>Score ${escapeHtml(state.score)}/${escapeHtml(total)}</span>
                <span>Phase 19 build</span>
              </div>
              <button id="voiceBtn">Enable Voice</button>
              <button id="startBtn" hidden>Start Assessment</button>
            </div>
          </section>
        </section>
      </main>
    `;

    setTerminal("SYSTEM ONLINE");
    window.QUIZ_SOUNDS?.boot?.();

    const rules = "Welcome to Quizzora. Here are the rules. One. Every wrong answer moves you forward. Two. Correct answers unlock the next feature of the website. Three. If even one answer is wrong, the complete website will remain locked. Four. Answer carefully. Have patience. Enjoy.";

    const voiceBtn = document.getElementById("voiceBtn");
    const startBtn = document.getElementById("startBtn");
    const unlockStart = () => {
      if (voiceBtn) voiceBtn.hidden = true;
      setStartVisible(true);
    };

    voiceBtn?.addEventListener("click", () => {
      voiceBtn.disabled = true;
      window.QUIZ_SOUNDS?.click?.();
      setTerminal("VOICE ENABLED");
      speak(rules, { rate: 0.94, onEnd: unlockStart, onError: unlockStart });
    });

    startBtn?.addEventListener("click", () => {
      window.QUIZ_SOUNDS?.click?.();
      window.dispatchEvent(new CustomEvent("quiz:start"));
    });
  }

  function renderQuestionLoader(state, total, activeFeature) {
    document.body.dataset.mode = "loading";
    app.innerHTML = `
      <main class="shell">
        <section class="frame unlocked-shell">
          <aside class="side-rail">
            <div class="rail-card active status-card">
              <div class="rail-label">Question</div>
              <div class="rail-value">${escapeHtml(state.index + 1)}/${escapeHtml(total)}</div>
            </div>
            <div class="rail-card status-card">
              <div class="rail-label">Score</div>
              <div class="rail-value">${escapeHtml(state.score)}</div>
            </div>
            <div class="rail-card status-card">
              <div class="rail-label">Unlocked</div>
              <div class="rail-value">${escapeHtml(state.unlocked.length)}/${escapeHtml(total)}</div>
            </div>
            <div class="rail-card status-card">
              <div class="rail-label">Status</div>
              <div class="rail-value">Decrypting</div>
            </div>
          </aside>

          <section class="main-stage">
            <div class="os-chrome">
              <span class="dot red"></span>
              <span class="dot yellow"></span>
              <span class="dot green"></span>
              <span class="machine-id">QUIZZORA OS // CONTROL SHELL</span>
            </div>

            <article class="panel question-card">
              ${renderHud(state, total, activeFeature)}
              <div class="loading-copy">Decrypting node...</div>
              <div class="loading-copy">Authenticating prompt...</div>
              <div class="loading-copy">Rendering question...</div>
              <div class="loading-bar"><span></span></div>
            </article>
          </section>
        </section>
      </main>
    `;
    setTerminal(`NODE ${state.index + 1} LOADING`);
  }

  function renderQuestion(question, state, total, activeFeature = "standby") {
    cancelTimers();
    bootStyles();
    document.body.dataset.mode = "quiz";

    renderQuestionLoader(state, total, activeFeature);

    currentLoadingTimer = setTimeout(() => {
      document.body.dataset.stage = activeFeature || "quiz";
      app.innerHTML = `
        <main class="shell">
          <section class="frame unlocked-shell">
            <aside class="side-rail">
              <div class="rail-card active status-card">
                <div class="rail-label">Question</div>
                <div class="rail-value">${escapeHtml(state.index + 1)}/${escapeHtml(total)}</div>
              </div>
              <div class="rail-card status-card">
                <div class="rail-label">Score</div>
                <div class="rail-value">${escapeHtml(state.score)}</div>
              </div>
              <div class="rail-card status-card">
                <div class="rail-label">Unlocked</div>
                <div class="rail-value">${escapeHtml(state.unlocked.length)}/${escapeHtml(total)}</div>
              </div>
              <div class="rail-card status-card">
                <div class="rail-label">Status</div>
                <div class="rail-value">Stable</div>
              </div>
            </aside>

            <section class="main-stage">
              <div class="os-chrome">
                <span class="dot red"></span>
                <span class="dot yellow"></span>
                <span class="dot green"></span>
                <span class="machine-id">QUIZZORA OS // CONTROL SHELL</span>
              </div>

              <article class="panel question-card">
                ${renderHud(state, total, activeFeature)}
                <div class="question-intro">Typewriter sequence engaged.</div>
                <h2 class="question-text typing-cursor" aria-live="polite"></h2>
                <div class="options" aria-busy="true"></div>
              </article>
            </section>
          </section>
        </main>
      `;

      const questionNode = app.querySelector(".question-text");
      const optionsNode = app.querySelector(".options");

      typewriterText(questionNode, question.question, () => {
        optionsNode.removeAttribute("aria-busy");
        optionsNode.innerHTML = question.options.map((option) => `
          <button class="option" data-value="${escapeHtml(option)}">${escapeHtml(option)}</button>
        `).join("");

        app.querySelectorAll(".option").forEach((btn) => {
          btn.addEventListener("click", () => {
            window.QUIZ_SOUNDS?.click?.();
            window.dispatchEvent(new CustomEvent("quiz:answer", {
              detail: { value: btn.dataset.value }
            }));
          });
        });
      }, 18);

      setTerminal(`NODE ${state.index + 1} READY`);
    }, 2100);
  }

  function flash(type, text) {
    const existing = app.querySelector(".flash");
    if (existing) existing.remove();
    const node = document.createElement("div");
    node.className = `flash ${type}`;
    node.textContent = text;
    app.prepend(node);
    setTimeout(() => {
      if (node.isConnected) node.remove();
    }, 1800);
  }

  function startCelebration() {
    document.body.dataset.mode = "celebration";
    document.body.dataset.stage = "celebration";
    const existing = document.querySelector(".celebration-overlay");
    if (existing) existing.remove();

    const overlay = document.createElement("div");
    overlay.className = "celebration-overlay";
    overlay.innerHTML = `
      <div class="celebration-rings">
        <div class="celebration-ring ring-a"></div>
        <div class="celebration-ring ring-b"></div>
        <div class="celebration-core"></div>
      </div>
      <div class="celebration-text">
        <span class="celebration-kicker">Perfect run</span>
        <span class="celebration-title">FULL SYSTEM MASTER</span>
      </div>
    `;
    document.body.appendChild(overlay);

    window.QUIZ_SOUNDS?.success?.();
    setTerminal("CELEBRATION SEQUENCE ACTIVE");

    endingTimers.add(setTimeout(() => {
      overlay.classList.add("fade-out");
      endingTimers.add(setTimeout(() => overlay.remove(), 900));
    }, 2400));
  }

  function startEnding(profile = {}) {
    document.body.dataset.mode = "ending";
    document.body.dataset.stage = "ending";
    document.body.classList.add("ending-active");
    document.body.classList.remove("celebration-active");

    const existing = document.querySelector(".reactor-overlay");
    if (existing) existing.remove();

    const overlay = document.createElement("div");
    overlay.className = "reactor-overlay";
    overlay.innerHTML = `
      <div class="reactor-vignette"></div>
      <div class="reactor-shell">
        <div class="reactor-rings">
          <div class="reactor-ring ring-a"></div>
          <div class="reactor-ring ring-b"></div>
          <div class="reactor-ring ring-c"></div>
        </div>
        <div class="reactor-core">
          <div class="reactor-pulse"></div>
          <div class="reactor-core-label">REACTOR ONLINE</div>
          <div class="reactor-core-subtitle">${escapeHtml(profile.rank || "SYSTEM ARCHITECT")}</div>
        </div>
        <div class="reactor-caption">Full system unlocked</div>
      </div>
    `;
    document.body.appendChild(overlay);

    window.QUIZ_SOUNDS?.reactorHum?.(true);
    window.QUIZ_SOUNDS?.reactorSwell?.();

    setTerminal("SYSTEM OVERRIDE ACCEPTED");
    endingTimers.add(setTimeout(() => setTerminal("REACTOR INITIALIZING"), 360));
    endingTimers.add(setTimeout(() => setTerminal("POWER CORE ONLINE"), 900));
    speak("Full system unlocked. Reactor online.", { rate: 0.92, pitch: 0.95, volume: 1 });
  }

  function renderResult(state, total, profile = {}) {
    cancelTimers();
    bootStyles();
    document.body.dataset.mode = "result";
    document.body.dataset.stage = "results";

    const accuracy = total ? Math.round((state.score / total) * 100) : 0;
    const solved = !state.hadFailure && state.score === total;
    const className = profile.className || (solved ? "complete" : "locked");
    const rank = profile.rank || (solved ? "SYSTEM ARCHITECT" : "NOVICE OPERATOR");
    const badge = profile.badge || (solved ? "FULL UNLOCK" : "LOCKED");
    const summary = profile.summary || (solved ? "All nodes cleared. Full website unlocked." : "");
    const badges = Array.isArray(profile.badges) ? profile.badges : [];

    app.innerHTML = `
      <main class="shell">
        <section class="frame result-shell">
          <aside class="side-rail">
            <div class="rail-card active">
              <div class="rail-label">System</div>
              <div class="rail-value">${escapeHtml(solved ? "Complete" : "Partial")}</div>
            </div>
            <div class="rail-card">
              <div class="rail-label">Score</div>
              <div class="rail-value">${escapeHtml(state.score)}/${escapeHtml(total)}</div>
            </div>
            <div class="rail-card">
              <div class="rail-label">Accuracy</div>
              <div class="rail-value">${escapeHtml(`${accuracy}%`)}</div>
            </div>
            <div class="rail-card">
              <div class="rail-label">State</div>
              <div class="rail-value">${escapeHtml(solved ? "Unlocked" : "Locked")}</div>
            </div>
          </aside>

          <section class="main-stage">
            <div class="os-chrome">
              <span class="dot red"></span>
              <span class="dot yellow"></span>
              <span class="dot green"></span>
              <span class="machine-id">QUIZZORA OS // FINAL REPORT</span>
            </div>

            <article class="panel result-card ${escapeHtml(className)}">
              ${renderHud(state, total, solved ? "COMPLETE" : "LOCKED")}
              <div class="micro-head">Final system report</div>
              <h2 class="result-heading">${escapeHtml(solved ? "Assessment complete" : "Complete website not unlocked :(")}</h2>
              ${summary ? `<p class="result-summary">${escapeHtml(summary)}</p>` : ""}
              <div class="result-topline">
                <div class="result-rank">${escapeHtml(rank)}</div>
                <div class="result-badge">${escapeHtml(badge)}</div>
              </div>
              <div class="result-grid">
                <div class="result-metric">
                  <div class="rail-label">Accuracy</div>
                  <div class="rail-value">${escapeHtml(`${accuracy}%`)}</div>
                </div>
                <div class="result-metric">
                  <div class="rail-label">State</div>
                  <div class="rail-value">${escapeHtml(solved ? "Unlocked full" : "Unlocked partial")}</div>
                </div>
                <div class="result-metric">
                  <div class="rail-label">Nodes</div>
                  <div class="rail-value">${escapeHtml(`${state.score}/${total}`)}</div>
                </div>
                <div class="result-metric">
                  <div class="rail-label">Profile</div>
                  <div class="rail-value">${escapeHtml(solved ? "Master" : "Locked")}</div>
                </div>
              </div>
              <div class="badge-row">
                ${badges.length ? badges.map((badgeText) => `<span class="badge-chip">${escapeHtml(badgeText)}</span>`).join("") : `<span class="badge-chip">${escapeHtml(solved ? "FULL RUN" : "PARTIAL RUN")}</span>`}
              </div>
              <button id="restartBtn">Run Again</button>
            </article>
          </section>
        </section>
      </main>
    `;

    setTerminal(`ASSESSMENT COMPLETE | SCORE ${state.score}/${total}`);

    if (solved) {
      window.QUIZ_SOUNDS?.success?.();
      setTimeout(() => startCelebration(), 260);
      setTimeout(() => startEnding(profile), 1500);
    } else {
      window.QUIZ_SOUNDS?.failure?.();
      speak("Complete website not unlocked.", { rate: 0.92, pitch: 0.95 });
    }

    const restartBtn = document.getElementById("restartBtn");
    restartBtn?.addEventListener("click", () => {
      window.QUIZ_SOUNDS?.success?.();
      window.dispatchEvent(new CustomEvent("quiz:restart"));
    });
  }

  return {
    app,
    normalize,
    escapeHtml,
    injectStyleOnce,
    bootStyles,
    cancelTimers,
    resetEffects,
    renderShell,
    renderQuestion,
    renderResult,
    flash,
    setTerminal,
    speak,
    setStartVisible,
    typewriterText,
    renderHud,
    startCelebration,
    startEnding
  };
})();

window.QUIZ_UI = UI;
