(() => {
  const questions = window.QUIZ_QUESTIONS || [];
  let state = window.QUIZ_STATE.loadState();
  let answerTimer = null;

  const unlockOrder = [
    "theme",
    "layout",
    "shell",
    "cards",
    "motion",
    "hud",
    "micro",
    "sound",
    "scan",
    "progress",
    "question-reveal",
    "feedback",
    "results",
    "badge",
    "polish",
    "celebration",
    "extended",
    "scan-lines",
    "ranking",
    "ending"
  ];

  const stageFiles = {
    theme: "./css/stage-01-theme.css",
    layout: "./css/stage-02-layout.css",
    shell: "./css/stage-03-shell.css",
    cards: "./css/stage-04-cards.css",
    motion: "./css/stage-05-motion.css",
    hud: "./css/stage-06-hud.css",
    micro: "./css/stage-07-micro.css",
    sound: "./css/stage-08-sound.css",
    scan: "./css/stage-09-scan.css",
    progress: "./css/stage-10-progress.css",
    "question-reveal": "./css/stage-11-question-reveal.css",
    feedback: "./css/stage-12-feedback.css",
    results: "./css/stage-13-results.css",
    badge: "./css/stage-14-badge.css",
    polish: "./css/stage-15-polish.css",
    celebration: "./css/stage-16-celebration.css",
    extended: "./css/stage-17-extended.css",
    "scan-lines": "./css/stage-18-scan-lines.css",
    ranking: "./css/stage-19-ranking.css",
    ending: "./css/stage-20-ending.css",
    "terminal-log": "./css/stage-07-terminal-log.css"
  };

  const featureNames = {
    theme: "Colors",
    layout: "Layout",
    shell: "Shell",
    cards: "Cards",
    motion: "Motion",
    hud: "HUD",
    micro: "Microinteractions",
    sound: "Audio",
    scan: "Scan layer",
    progress: "Progress",
    "question-reveal": "Reveal",
    feedback: "Feedback",
    results: "Results",
    badge: "Badge",
    polish: "Polish",
    celebration: "Celebration",
    extended: "Extended HUD",
    "scan-lines": "Scan lines",
    ranking: "Ranking",
    ending: "Ending"
  };

  const terminalMessages = {
    1: "Colors Unlocked",
    2: "Layout Unlocked",
    3: "Shell Stabilized",
    4: "Cards Online",
    5: "Motion Engine Active",
    6: "HUD Enabled",
    7: "Microinteractions Ready",
    8: "Audio Channel Live",
    9: "Scan Layer Active",
    10: "Progress Module Online",
    11: "Reveal Engine Active",
    12: "Feedback Engine Ready",
    13: "Results Module Online",
    14: "Badge System Ready",
    15: "Polish Layer Applied",
    16: "Celebration Layer Ready",
    17: "Extended HUD Ready",
    18: "Scan Lines Enabled",
    19: "Ranking System Ready",
    20: "Ending Sequence Complete"
  };

  function logTerminal(message) {
    window.QUIZ_UI.setTerminal(message);
  }

  function speak(text, options = {}) {
    if (window.QUIZ_VOICE && typeof window.QUIZ_VOICE.speak === "function") {
      return window.QUIZ_VOICE.speak(text, options);
    }
    return Promise.resolve("unavailable");
  }

  function loadAllStyles() {
    window.QUIZ_UI.bootStyles();
    Object.entries(stageFiles).forEach(([stage, href]) => {
      window.QUIZ_UI.injectStyleOnce(`stage-${stage}`, href);
    });
  }

  function setStage(stage) {
    document.body.dataset.stage = stage;
  }

  function currentQuestion() {
    return questions[state.index];
  }

  function save() {
    window.QUIZ_STATE.saveState(state);
  }

  function pendingFeatureName() {
    const next = unlockOrder.find((stage) => !state.unlocked.includes(stage));
    return featureNames[next] || "standby";
  }

  function ensureNextStage() {
    const next = unlockOrder.find((stage) => !state.unlocked.includes(stage));
    if (!next) return null;
    const href = stageFiles[next];
    if (href && !document.getElementById(`stage-${next}`)) {
      window.QUIZ_UI.injectStyleOnce(`stage-${next}`, href);
    }
    setStage(next);
    state.unlocked.push(next);
    return next;
  }

  function getResultProfile() {
    const total = questions.length || 1;
    const accuracy = Math.round((state.score / total) * 100);
    const perfect = !state.hadFailure && state.score === total;

    const badges = [];
    if (state.score >= 1) badges.push("FIRST NODE");
    if (state.score >= Math.ceil(total * 0.5)) badges.push("MIDWAY CONTROL");
    if (accuracy >= 75) badges.push("STABLE HAND");
    if (accuracy >= 90) badges.push("ELITE OPERATOR");
    if (perfect) badges.push("FULL SYSTEM MASTER");

    if (perfect) {
      return {
        rank: "SYSTEM ARCHITECT",
        className: "complete",
        summary: "All nodes cleared. Full website unlocked.",
        badge: "FULL UNLOCK",
        badges,
        celebrate: true
      };
    }

    if (accuracy >= 90) {
      return {
        rank: "STRATEGIC THINKER",
        className: "near-perfect",
        summary: "Very strong performance, but the full build is still not unlocked.",
        badge: "ALMOST THERE",
        badges,
        celebrate: false
      };
    }

    if (accuracy >= 70) {
      return {
        rank: "ADVANCED OPERATOR",
        className: "partial",
        summary: "Good control over the system. More precision is needed.",
        badge: "PARTIAL UNLOCK",
        badges,
        celebrate: false
      };
    }

    return {
      rank: "NOVICE OPERATOR",
      className: "locked",
      summary: "The system remains unstable. The website is not fully unlocked.",
      badge: "LOCKED",
      badges,
      celebrate: false
    };
  }

  function renderLanding() {
    document.body.dataset.mode = "idle";
    setStage("boot");
    loadAllStyles();
    window.QUIZ_UI.renderShell(state, questions.length);
    logTerminal("SYSTEM READY");
    window.QUIZ_SOUNDS.ambient(true);
    save();
  }

  function renderQuestion() {
    const question = currentQuestion();
    if (!question) return renderResult();

    document.body.dataset.mode = "quiz";
    const activeFeature = pendingFeatureName();
    window.QUIZ_SOUNDS.transition();
    window.QUIZ_UI.renderQuestion(question, state, questions.length, activeFeature);
    logTerminal(`NODE ${state.index + 1} LOADING`);
  }

  function renderResult() {
    if (answerTimer) {
      clearTimeout(answerTimer);
      answerTimer = null;
    }

    state.completed = true;
    save();

    const profile = getResultProfile();
    window.QUIZ_UI.renderResult(state, questions.length, profile);

    if (profile.celebrate) {
      window.QUIZ_UI.startCelebration();
      setTimeout(() => {
        window.QUIZ_UI.startEnding(profile);
      }, 1400);
    }

    logTerminal(`ASSESSMENT COMPLETE | SCORE ${state.score}/${questions.length}`);
  }

  function answer(value) {
    const question = currentQuestion();
    if (!question) return;

    const selected = window.QUIZ_UI.normalize(value);
    const accepted = question.accepted.map(window.QUIZ_UI.normalize);
    const isCorrect = accepted.includes(selected);

    const clicked = [...document.querySelectorAll(".option")].find(
      (btn) => window.QUIZ_UI.normalize(btn.dataset.value) === selected
    );
    if (clicked) {
      clicked.classList.add(isCorrect ? "correct" : "wrong");
    }

    document.querySelectorAll(".option").forEach((btn) => {
      btn.disabled = true;
    });

    const pendingFeature = pendingFeatureName();

    if (isCorrect) {
      state.score += 1;
      const unlockedStage = ensureNextStage();
      const unlockedFeature = featureNames[unlockedStage] || pendingFeature;
      const msg = `Correct answer, ${unlockedFeature} unlocked.`;
      window.QUIZ_UI.flash("good", msg);
      logTerminal(`CORRECT | ${msg}`);
      window.QUIZ_SOUNDS.unlock();
      speak(msg, { rate: 1.0 });
      save();
    } else {
      state.hadFailure = true;
      const msg = `Wrong answer, unable to unlock ${pendingFeature.toLowerCase()}.`;
      window.QUIZ_UI.flash("bad", msg);
      logTerminal(`WRONG | ${msg}`);
      window.QUIZ_SOUNDS.failure();
      speak(msg, { rate: 0.95 });
      save();
    }

    if (answerTimer) clearTimeout(answerTimer);
    answerTimer = setTimeout(() => {
      state.index += 1;
      answerTimer = null;
      if (state.index >= questions.length) {
        renderResult();
      } else {
        renderQuestion();
      }
    }, 2100);
  }

  function restart() {
    if (answerTimer) {
      clearTimeout(answerTimer);
      answerTimer = null;
    }

    window.QUIZ_UI.cancelTimers();
    window.QUIZ_UI.resetEffects();
    window.QUIZ_VOICE?.stop?.();
    window.QUIZ_SOUNDS?.ambient?.(false);
    window.QUIZ_SOUNDS?.reactorHum?.(false);

    state = window.QUIZ_STATE.resetState();
    state.hadFailure = false;
    renderLanding();
  }

  window.addEventListener("quiz:start", () => {
    state.started = true;
    save();
    window.QUIZ_SOUNDS.boot();
    speak("Launching CSS interface.", { rate: 0.96 });
    logTerminal("LAUNCH SEQUENCE STARTED");
    renderQuestion();
  });

  window.addEventListener("quiz:answer", (event) => answer(event.detail.value));
  window.addEventListener("quiz:restart", restart);

  renderLanding();
})();
