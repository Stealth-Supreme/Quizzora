const AUDIO_ENGINE = (() => {
  let ctx = null;
  let master = null;
  let compressor = null;
  let ambientNodes = null;

  function getCtx() {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return null;
    if (!ctx) {
      ctx = new AC();
      compressor = ctx.createDynamicsCompressor();
      master = ctx.createGain();

      compressor.threshold.value = -28;
      compressor.knee.value = 22;
      compressor.ratio.value = 8;
      compressor.attack.value = 0.004;
      compressor.release.value = 0.18;

      master.gain.value = 0.9;
      master.connect(compressor);
      compressor.connect(ctx.destination);
    }
    if (ctx.state === "suspended") ctx.resume().catch(() => {});
    return ctx;
  }

  function connect(node) {
    const c = getCtx();
    if (!c || !master) return false;
    node.connect(master);
    return true;
  }

  function clampGain(value) {
    return Math.max(0.0001, Math.min(0.6, value));
  }

  function envelope(gainNode, start, peak, end, attack = 0.008, release = 0.08) {
    const g = gainNode.gain;
    g.cancelScheduledValues(start);
    g.setValueAtTime(0.0001, start);
    g.exponentialRampToValueAtTime(clampGain(peak), start + attack);
    g.exponentialRampToValueAtTime(0.0001, Math.max(start + release, end));
  }

  function stopNode(node, when) {
    try { node.stop(when); } catch {}
  }

  function tone({
    freq = 440,
    dur = 0.09,
    type = "sine",
    gain = 0.04,
    delay = 0,
    detune = 0,
    filter = null
  }) {
    const c = getCtx();
    if (!c) return;

    try {
      const o = c.createOscillator();
      const g = c.createGain();
      const chain = [o, g];

      o.type = type;
      o.frequency.value = freq;
      if (detune) o.detune.value = detune;

      let last = g;
      if (filter) {
        const f = c.createBiquadFilter();
        f.type = filter.type || "lowpass";
        if (Number.isFinite(filter.freq)) f.frequency.value = filter.freq;
        if (Number.isFinite(filter.q)) f.Q.value = filter.q;
        o.connect(f);
        f.connect(g);
      } else {
        o.connect(g);
      }

      connect(g);

      const s = c.currentTime + delay;
      o.start(s);
      envelope(g, s, gain, s + dur, 0.006, Math.max(dur - 0.01, 0.03));
      stopNode(o, s + dur + 0.05);
    } catch {
      // ignore audio failures
    }
  }

  function noiseBurst({
    dur = 0.06,
    gain = 0.02,
    delay = 0,
    type = "bandpass",
    freq = 2400,
    q = 0.7
  }) {
    const c = getCtx();
    if (!c) return;

    try {
      const bufferSize = Math.max(1, Math.floor(c.sampleRate * dur));
      const buffer = c.createBuffer(1, bufferSize, c.sampleRate);
      const data = buffer.getChannelData(0);
      for (let i = 0; i < bufferSize; i += 1) {
        data[i] = (Math.random() * 2 - 1) * 0.9;
      }

      const src = c.createBufferSource();
      const g = c.createGain();
      const f = c.createBiquadFilter();
      f.type = type;
      f.frequency.value = freq;
      f.Q.value = q;

      src.buffer = buffer;
      src.connect(f);
      f.connect(g);
      connect(g);

      const s = c.currentTime + delay;
      src.start(s);
      envelope(g, s, gain, s + dur, 0.004, Math.max(dur - 0.01, 0.02));
      stopNode(src, s + dur + 0.02);
    } catch {
      // ignore audio failures
    }
  }

  function stopAmbient() {
    if (!ambientNodes) return;
    try { ambientNodes.osc1.stop(); } catch {}
    try { ambientNodes.osc2.stop(); } catch {}
    try { ambientNodes.mod.stop(); } catch {}
    ambientNodes = null;
  }

  function startAmbient({ base = 42, gain = 0.008, color = "sine" } = {}) {
    const c = getCtx();
    if (!c || ambientNodes) return;

    try {
      const osc1 = c.createOscillator();
      const osc2 = c.createOscillator();
      const mod = c.createOscillator();
      const gainNode = c.createGain();
      const filter = c.createBiquadFilter();

      filter.type = "lowpass";
      filter.frequency.value = 340;
      filter.Q.value = 0.8;

      osc1.type = color;
      osc2.type = "triangle";
      osc1.frequency.value = base;
      osc2.frequency.value = base * 1.49;
      mod.type = "sine";
      mod.frequency.value = 0.14;

      const modGain = c.createGain();
      modGain.gain.value = 0.0048;
      mod.connect(modGain);
      modGain.connect(gainNode.gain);

      osc1.connect(filter);
      osc2.connect(filter);
      filter.connect(gainNode);
      connect(gainNode);

      gainNode.gain.value = gain;

      const now = c.currentTime;
      osc1.start(now);
      osc2.start(now);
      mod.start(now);

      ambientNodes = { osc1, osc2, mod, gainNode, filter, modGain };
    } catch {
      ambientNodes = null;
    }
  }

  function click() {
    tone({
      freq: 310,
      dur: 0.038,
      type: "triangle",
      gain: 0.09,
      filter: { type: "highpass", freq: 900, q: 0.6 }
    });
    noiseBurst({
      dur: 0.02,
      gain: 0.035,
      type: "bandpass",
      freq: 4200,
      q: 0.9
    });
  }

  function boot() {
    tone({ freq: 122, dur: 0.16, type: "triangle", gain: 0.07 });
    tone({ freq: 184, dur: 0.12, type: "triangle", gain: 0.05, delay: 0.08 });
    noiseBurst({ dur: 0.055, gain: 0.016, delay: 0.02, freq: 1800, q: 0.5 });
    startAmbient({ base: 34, gain: 0.006 });
  }

  function unlock() {
    tone({ freq: 520, dur: 0.08, type: "triangle", gain: 0.08 });
    tone({ freq: 740, dur: 0.08, type: "triangle", gain: 0.07, delay: 0.07 });
    tone({ freq: 990, dur: 0.07, type: "sine", gain: 0.05, delay: 0.14 });
    noiseBurst({ dur: 0.045, gain: 0.022, delay: 0.03, freq: 3600, q: 0.8 });
  }

  function success() {
    tone({ freq: 628, dur: 0.11, type: "triangle", gain: 0.085 });
    tone({ freq: 792, dur: 0.1, type: "triangle", gain: 0.07, delay: 0.08 });
    tone({ freq: 1056, dur: 0.11, type: "sine", gain: 0.06, delay: 0.16 });
    noiseBurst({ dur: 0.07, gain: 0.018, delay: 0.03, freq: 2600, q: 0.7 });
  }

  function failure() {
    tone({ freq: 164, dur: 0.16, type: "sawtooth", gain: 0.06 });
    tone({ freq: 126, dur: 0.19, type: "sawtooth", gain: 0.05, delay: 0.08 });
    noiseBurst({ dur: 0.09, gain: 0.022, delay: 0.03, freq: 900, q: 0.4 });
  }

  function typingTick() {
    tone({
      freq: 1480,
      dur: 0.014,
      type: "square",
      gain: 0.016,
      filter: { type: "highpass", freq: 2000, q: 0.2 }
    });
  }

  function transition() {
    noiseBurst({ dur: 0.06, gain: 0.014, freq: 1700, q: 0.9 });
    tone({ freq: 420, dur: 0.07, type: "triangle", gain: 0.03, delay: 0.02 });
    tone({ freq: 220, dur: 0.09, type: "sine", gain: 0.022, delay: 0.04 });
  }

  function ambient(on = true) {
    if (on) {
      startAmbient({ base: 34, gain: 0.006, color: "sine" });
    } else {
      stopAmbient();
    }
  }

  function reactorHum(on = true) {
    if (on) {
      stopAmbient();
      startAmbient({ base: 28, gain: 0.01, color: "triangle" });
    } else {
      stopAmbient();
    }
  }

  function reactorSwell() {
    tone({ freq: 196, dur: 0.24, type: "triangle", gain: 0.085 });
    tone({ freq: 294, dur: 0.26, type: "triangle", gain: 0.075, delay: 0.06 });
    tone({ freq: 392, dur: 0.28, type: "sine", gain: 0.07, delay: 0.12 });
    noiseBurst({ dur: 0.18, gain: 0.03, delay: 0.04, freq: 1300, q: 0.75 });
  }

  function playTone(kind = "click") {
    if (kind === "success") return success();
    if (kind === "failure") return failure();
    if (kind === "unlock") return unlock();
    if (kind === "boot") return boot();
    if (kind === "typing") return typingTick();
    if (kind === "transition") return transition();
    if (kind === "reactor") return reactorSwell();
    return click();
  }

  return {
    click,
    success,
    failure,
    boot,
    unlock,
    typingTick,
    transition,
    ambient,
    reactorHum,
    reactorSwell,
    stopAmbient,
    playTone
  };
})();

window.QUIZ_SOUNDS = AUDIO_ENGINE;
