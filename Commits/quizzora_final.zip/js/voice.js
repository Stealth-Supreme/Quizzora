const QUIZ_VOICE = (() => {
  const synth = window.speechSynthesis || null;
  let voice = null;
  let ready = false;
  let queue = Promise.resolve();

  function pickVoice() {
    if (!synth) return null;
    const voices = synth.getVoices() || [];
    voice = voices.find(v => /en/i.test(v.lang) && /female/i.test(v.name)) ||
            voices.find(v => /en/i.test(v.lang)) ||
            voices[0] || null;
    ready = true;
    return voice;
  }

  if (synth) {
    synth.onvoiceschanged = pickVoice;
    pickVoice();
  }

  function resolveFallback(options, mode) {
    try {
      if (mode === "error" && typeof options.onError === "function") options.onError();
      if (typeof options.onEnd === "function") options.onEnd();
    } catch {
      // ignore callback errors
    }
  }

  function speak(text, options = {}) {
    const message = String(text ?? "").trim();
    queue = queue.then(() => new Promise((resolve) => {
      if (!synth || !("SpeechSynthesisUtterance" in window) || !message) {
        resolveFallback(options, "unavailable");
        resolve("unavailable");
        return;
      }

      try {
        synth.cancel();
        if (!ready) pickVoice();

        const utter = new SpeechSynthesisUtterance(message);
        utter.lang = options.lang || "en-US";
        utter.rate = Number.isFinite(options.rate) ? options.rate : 1;
        utter.pitch = Number.isFinite(options.pitch) ? options.pitch : 1;
        utter.volume = Number.isFinite(options.volume) ? options.volume : 1;
        if (voice) utter.voice = voice;

        utter.onend = () => {
          try {
            if (typeof options.onEnd === "function") options.onEnd();
          } finally {
            resolve("ended");
          }
        };

        utter.onerror = () => {
          resolveFallback(options, "error");
          resolve("error");
        };

        synth.speak(utter);
      } catch {
        resolveFallback(options, "error");
        resolve("error");
      }
    }));
    return queue;
  }

  function stop() {
    if (synth) synth.cancel();
  }

  return { speak, stop };
})();

window.QUIZ_VOICE = QUIZ_VOICE;
