const QUIZ_STORAGE_KEY = "quizzora-phase14-v3";

const defaultState = {
  started: false,
  index: 0,
  score: 0,
  unlocked: [],
  completed: false,
  hadFailure: false
};

function deepClone(value) {
  return JSON.parse(JSON.stringify(value));
}

function clearStoredProgress() {
  try {
    localStorage.removeItem(QUIZ_STORAGE_KEY);
  } catch {
    // ignore storage access failures
  }
  try {
    sessionStorage.removeItem(QUIZ_STORAGE_KEY);
  } catch {
    // ignore storage access failures
  }
}

function loadState() {
  clearStoredProgress();
  return deepClone(defaultState);
}

function saveState() {
  // Intentionally disabled. Progress must not persist across refresh.
}

function resetState() {
  clearStoredProgress();
  return deepClone(defaultState);
}

window.QUIZ_STATE = { loadState, saveState, resetState };
