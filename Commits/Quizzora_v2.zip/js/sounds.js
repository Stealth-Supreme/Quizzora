(() => {
  let ctx = null;
  let master = null;
  let ambience = null;
  let reactorLayer = null;

  const ensure = () => {
    const Ctor = window.AudioContext || window.webkitAudioContext;
    if (!Ctor) return null;
    if (!ctx) {
      ctx = new Ctor();
      master = ctx.createGain();
      const comp = ctx.createDynamicsCompressor();
      const limiter = ctx.createBiquadFilter();
      limiter.type = 'lowpass';
      limiter.frequency.value = 12000;
      master.gain.value = 0.9;
      comp.threshold.value = -18;
      comp.knee.value = 24;
      comp.ratio.value = 8;
      comp.attack.value = 0.003;
      comp.release.value = 0.22;
      master.connect(comp);
      comp.connect(limiter);
      limiter.connect(ctx.destination);
    }
    if (ctx.state === 'suspended') ctx.resume().catch(() => {});
    return ctx;
  };

  const out = () => master;

  const shapedNoise = (duration, gainValue, filterType = 'highpass', freq = 2000, q = 0.8) => {
    const c = ensure();
    if (!c) return;
    const bufferSize = Math.max(1, Math.floor(c.sampleRate * duration));
    const buffer = c.createBuffer(1, bufferSize, c.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i += 1) data[i] = (Math.random() * 2) - 1;
    const src = c.createBufferSource();
    src.buffer = buffer;
    const filter = c.createBiquadFilter();
    filter.type = filterType;
    filter.frequency.value = freq;
    filter.Q.value = q;
    const gain = c.createGain();
    gain.gain.value = gainValue;
    src.connect(filter);
    filter.connect(gain);
    gain.connect(out());
    src.start();
    src.stop(c.currentTime + duration);
  };

  const tone = ({ freq = 440, dur = 0.08, type = 'triangle', gain = 0.08, detune = 0, delay = 0, filter = null } = {}) => {
    const c = ensure();
    if (!c) return;
    const osc = c.createOscillator();
    const amp = c.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    osc.detune.value = detune;
    amp.gain.value = 0.0001;
    osc.connect(amp);
    if (filter) {
      const biquad = c.createBiquadFilter();
      biquad.type = filter.type || 'lowpass';
      biquad.frequency.value = filter.freq || 12000;
      biquad.Q.value = filter.q || 0.7;
      amp.connect(biquad);
      biquad.connect(out());
    } else {
      amp.connect(out());
    }
    const now = c.currentTime + delay;
    const peak = Math.max(0.0001, gain);
    amp.gain.setValueAtTime(0.0001, now);
    amp.gain.exponentialRampToValueAtTime(peak, now + 0.008);
    amp.gain.exponentialRampToValueAtTime(0.0001, now + dur);
    osc.start(now);
    osc.stop(now + dur + 0.03);
  };

  const playChord = (frequencies, options = {}) => {
    frequencies.forEach((freq, index) => tone({ ...options, freq, delay: (options.delay || 0) + index * 0.05 }));
  };

  const stopLayer = (layer) => {
    if (!layer) return;
    try { layer.osc1.stop(); } catch {}
    try { layer.osc2.stop(); } catch {}
    try { layer.mod.stop(); } catch {}
  };

  const startAmbient = ({ base = 34, gain = 0.008, color = 'sine' } = {}) => {
    const c = ensure();
    if (!c || ambience) return;
    const osc1 = c.createOscillator();
    const osc2 = c.createOscillator();
    const mod = c.createOscillator();
    const mix = c.createGain();
    const filter = c.createBiquadFilter();
    const modGain = c.createGain();
    filter.type = 'lowpass';
    filter.frequency.value = 420;
    filter.Q.value = 0.65;
    osc1.type = color;
    osc2.type = 'triangle';
    mod.type = 'sine';
    osc1.frequency.value = base;
    osc2.frequency.value = base * 1.495;
    mod.frequency.value = 0.11;
    modGain.gain.value = 0.0048;
    mod.connect(modGain);
    modGain.connect(mix.gain);
    osc1.connect(filter);
    osc2.connect(filter);
    filter.connect(mix);
    mix.gain.value = gain;
    mix.connect(out());
    osc1.start();
    osc2.start();
    mod.start();
    ambience = { osc1, osc2, mod, mix, filter, modGain };
  };

  const stopAmbient = () => {
    stopLayer(ambience);
    ambience = null;
  };

  const startReactorLayer = () => {
    stopAmbient();
    const c = ensure();
    if (!c || reactorLayer) return;
    const osc1 = c.createOscillator();
    const osc2 = c.createOscillator();
    const mod = c.createOscillator();
    const mix = c.createGain();
    const filter = c.createBiquadFilter();
    const modGain = c.createGain();
    filter.type = 'bandpass';
    filter.frequency.value = 180;
    filter.Q.value = 0.9;
    osc1.type = 'triangle';
    osc2.type = 'sine';
    mod.type = 'sine';
    osc1.frequency.value = 32;
    osc2.frequency.value = 65;
    mod.frequency.value = 0.08;
    modGain.gain.value = 0.014;
    mod.connect(modGain);
    modGain.connect(mix.gain);
    osc1.connect(filter);
    osc2.connect(filter);
    filter.connect(mix);
    mix.gain.value = 0.02;
    mix.connect(out());
    osc1.start();
    osc2.start();
    mod.start();
    reactorLayer = { osc1, osc2, mod, mix, filter, modGain };
  };

  const stopReactorLayer = () => {
    stopLayer(reactorLayer);
    reactorLayer = null;
  };

  const click = () => {
    ensure();
    tone({ freq: 520, dur: 0.03, type: 'square', gain: 0.045, filter: { type: 'highpass', freq: 2400, q: 0.2 } });
    tone({ freq: 860, dur: 0.04, type: 'triangle', gain: 0.03, delay: 0.012, filter: { type: 'highpass', freq: 2600, q: 0.3 } });
    shapedNoise(0.017, 0.055, 'bandpass', 3600, 0.7);
  };

  const boot = () => {
    ensure();
    playChord([120, 180], { dur: 0.12, type: 'triangle', gain: 0.05 });
    shapedNoise(0.06, 0.02, 'highpass', 1600, 0.4);
    startAmbient({ base: 32, gain: 0.006 });
  };

  const unlock = () => {
    ensure();
    playChord([520, 740, 1040], { dur: 0.08, type: 'triangle', gain: 0.07 });
    shapedNoise(0.05, 0.022, 'bandpass', 3200, 0.85);
  };

  const success = () => {
    ensure();
    playChord([620, 780, 1048], { dur: 0.11, type: 'sine', gain: 0.08 });
    shapedNoise(0.075, 0.02, 'bandpass', 2400, 0.75);
  };

  const failure = () => {
    ensure();
    tone({ freq: 168, dur: 0.17, type: 'sawtooth', gain: 0.04, filter: { type: 'lowpass', freq: 1200, q: 0.4 } });
    tone({ freq: 118, dur: 0.21, type: 'sawtooth', gain: 0.03, delay: 0.08, filter: { type: 'lowpass', freq: 900, q: 0.4 } });
    shapedNoise(0.08, 0.016, 'bandpass', 980, 0.45);
  };

  const typingTick = () => {
    tone({ freq: 1520, dur: 0.014, type: 'square', gain: 0.012, filter: { type: 'highpass', freq: 2600, q: 0.2 } });
  };

  const transition = () => {
    shapedNoise(0.05, 0.015, 'bandpass', 1800, 0.7);
    tone({ freq: 440, dur: 0.06, type: 'triangle', gain: 0.022, delay: 0.02 });
  };

  const ambient = (on = true) => {
    if (on) startAmbient(); else stopAmbient();
  };

  const reactorHum = (on = true) => {
    if (on) startReactorLayer(); else stopReactorLayer();
  };

  const reactorSwell = () => {
    ensure();
    playChord([196, 262, 330], { dur: 0.3, type: 'sine', gain: 0.045 });
    setTimeout(() => playChord([392, 523, 659], { dur: 0.35, type: 'triangle', gain: 0.05 }), 180);
    setTimeout(() => shapedNoise(0.28, 0.012, 'bandpass', 1400, 0.5), 60);
  };

  window.QuizzoraSounds = {
    ensure,
    boot,
    click,
    unlock,
    success,
    failure,
    typingTick,
    transition,
    ambient,
    reactorHum,
    reactorSwell,
  };
})();
