(() => {
  const app = document.getElementById('app');
  const terminal = document.getElementById('terminal');
  const TERMINAL_PREFIX = 'Adavya>';
  const history = [];
  const timers = new Set();
  let loaderTimer = null;
  let typeTimer = null;
  let currentRevealToken = 0;
  let startVisible = false;
  let voiceReady = false;

  const clearTimers = () => {
    timers.forEach((id) => clearTimeout(id));
    timers.clear();
    if (loaderTimer) clearTimeout(loaderTimer);
    if (typeTimer) clearInterval(typeTimer);
    loaderTimer = null;
    typeTimer = null;
  };

  const normalize = (value) => String(value ?? '').trim().toLowerCase();

  const escapeHtml = (value) => String(value ?? '').replace(/[&<>"]|'/g, (ch) => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[ch]));

  const setMode = (mode) => {
    document.body.dataset.mode = mode;
  };

  const setStageFlags = (stages = []) => {
    document.body.dataset.unlocked = stages.join(' ');
  };

  const bootShell = () => {
    app.innerHTML = `
      <main class="boot-screen">
        <section class="boot-card glass-panel">
          <div class="boot-kicker">QUIZZORA_v2 // BOOT SEQUENCE</div>
          <h1>Futuristic quiz operating system</h1>
          <p class="boot-copy">Enable voice to initialize the rules engine, then start the assessment.</p>
          <div class="boot-rules" aria-live="polite">
            <p>Rules will be spoken before the test begins.</p>
            <p>Progress resets on refresh.</p>
            <p>Wrong answers move forward without unlocking anything.</p>
          </div>
          <div class="boot-actions">
            <button id="enableVoiceBtn" class="primary-btn">Enable Voice</button>
            <button id="startBtn" class="primary-btn hidden">Start Assessment</button>
          </div>
          <div class="boot-status" id="bootStatus">System idle.</div>
        </section>
      </main>
    `;
  };

  const renderQuizShell = ({ state, total, question, unlockLabel, onAnswer }) => {
    const stage = unlockLabel || 'standby';
    app.innerHTML = `
      <main class="shell-stage ${stage}">
        <section class="frame shell-frame">
          <aside class="side-rail glass-panel">
            <div class="rail-card active">
              <div class="rail-label">SYSTEM</div>
              <div class="rail-value">ONLINE</div>
            </div>
            <div class="rail-card">
              <div class="rail-label">NODE</div>
              <div class="rail-value">${escapeHtml(state.currentQuestionIndex + 1)}/${escapeHtml(total)}</div>
            </div>
            <div class="rail-card">
              <div class="rail-label">SCORE</div>
              <div class="rail-value">${escapeHtml(state.score)}</div>
            </div>
            <div class="rail-card">
              <div class="rail-label">STATUS</div>
              <div class="rail-value">${escapeHtml(stage.toUpperCase())}</div>
            </div>
            <div class="rail-card">
              <div class="rail-label">NEXT</div>
              <div class="rail-value" id="nextFeatureLabel">${escapeHtml(stage)}</div>
            </div>
            <div class="rail-card">
              <div class="rail-label">UNLOCKED</div>
              <div class="rail-value">${escapeHtml(state.unlockedStages.length)}/${escapeHtml(total)}</div>
            </div>
          </aside>
          <section class="main-stage">
            <div class="os-chrome glass-panel">
              <span class="dot red"></span><span class="dot amber"></span><span class="dot green"></span>
              <span class="machine-id">QUIZZORA OS // CONTROL SHELL</span>
            </div>
            <article class="quiz-card glass-panel" id="quizCard">
              <div class="hud-grid">${renderHud(state, total, stage)}</div>
              <div class="terminal-head">${TERMINAL_PREFIX} NODE INITIALIZED</div>
              <div class="reveal-stage">
                <div class="reveal-lines">
                  <span>Decrypting node...</span>
                  <span>Authenticating prompt...</span>
                  <span>Rendering question...</span>
                </div>
                <div class="reveal-bar"><i></i></div>
              </div>
              <div class="question-block hidden" id="questionBlock">
                <div class="question-intro">Typewriter sequence engaged.</div>
                <h2 class="question-text typing-cursor" id="questionText" aria-live="polite"></h2>
                <div class="options" id="optionsNode" aria-busy="true"></div>
              </div>
            </article>
          </section>
        </section>
      </main>
    `;

    scheduleQuestionReveal(question, state, total, onAnswer, stage);
  };

  const renderHud = (state, total, stage) => {
    const answered = state.currentQuestionIndex;
    const progress = total ? Math.round((state.score / total) * 100) : 0;
    const unlocked = state.unlockedStages.length;
    return `
      <div class="hud-chip"><span>NODE</span><strong>${escapeHtml(answered + 1)}/${escapeHtml(total)}</strong></div>
      <div class="hud-chip"><span>SCORE</span><strong>${escapeHtml(state.score)}</strong></div>
      <div class="hud-chip"><span>STATUS</span><strong>${escapeHtml(stage.toUpperCase())}</strong></div>
      <div class="hud-chip"><span>UNLOCKED</span><strong>${escapeHtml(unlocked)}</strong></div>
      <div class="hud-chip"><span>NEXT</span><strong>${escapeHtml(stage)}</strong></div>
      <div class="hud-chip"><span>RATIO</span><strong>${escapeHtml(progress)}%</strong></div>
    `;
  };

  const renderResult = ({ state, total, profile, onRestart }) => {
    app.innerHTML = `
      <main class="shell-stage results-stage">
        <section class="frame result-frame">
          <aside class="side-rail glass-panel">
            <div class="rail-card active">
              <div class="rail-label">SYSTEM</div>
              <div class="rail-value">${escapeHtml(profile.complete ? 'COMPLETE' : 'LOCKED')}</div>
            </div>
            <div class="rail-card"><div class="rail-label">NODE</div><div class="rail-value">${escapeHtml(state.currentQuestionIndex)}/${escapeHtml(total)}</div></div>
            <div class="rail-card"><div class="rail-label">SCORE</div><div class="rail-value">${escapeHtml(state.score)}</div></div>
            <div class="rail-card"><div class="rail-label">STATUS</div><div class="rail-value">${escapeHtml(profile.rank)}</div></div>
            <div class="rail-card"><div class="rail-label">UNLOCKED</div><div class="rail-value">${escapeHtml(state.unlockedStages.length)}/${escapeHtml(total)}</div></div>
          </aside>
          <section class="main-stage">
            <div class="os-chrome glass-panel">
              <span class="dot red"></span><span class="dot amber"></span><span class="dot green"></span>
              <span class="machine-id">QUIZZORA OS // FINAL REPORT</span>
            </div>
            <article class="result-card glass-panel ${profile.complete ? 'complete' : 'locked'}">
              <div class="hud-grid">${renderHud(state, total, profile.complete ? 'COMPLETE' : 'LOCKED')}</div>
              <div class="micro-head">Final system report</div>
              <h2 class="result-heading">${profile.complete ? 'Assessment complete' : 'Complete website not unlocked :('}</h2>
              ${profile.complete ? `<p class="result-summary">${escapeHtml(profile.summary)}</p>` : ''}
              <div class="result-topline">
                <div class="result-rank">${escapeHtml(profile.rank)}</div>
                <div class="result-badge">${escapeHtml(profile.badge)}</div>
              </div>
              <div class="result-grid">
                <div class="result-metric"><span>Accuracy</span><strong>${escapeHtml(profile.accuracy)}%</strong></div>
                <div class="result-metric"><span>State</span><strong>${escapeHtml(profile.complete ? 'Unlocked full' : 'Partial')}</strong></div>
                <div class="result-metric"><span>Profile</span><strong>${escapeHtml(profile.profileLine)}</strong></div>
                <div class="result-metric"><span>Nodes</span><strong>${escapeHtml(state.score)}/${escapeHtml(total)}</strong></div>
              </div>
              <div class="badge-row">${profile.badges.map((b) => `<span class="badge-chip">${escapeHtml(b)}</span>`).join('')}</div>
              <div class="result-actions">
                <button id="restartBtn" class="primary-btn">Run Again</button>
              </div>
            </article>
          </section>
        </section>
      </main>
    `;
    document.getElementById('restartBtn')?.addEventListener('click', onRestart, { once: true });
  };

  const renderCelebration = () => {
    const overlay = document.createElement('div');
    overlay.className = 'celebration-overlay';
    overlay.innerHTML = `
      <div class="celebration-core"></div>
      <div class="celebration-rings ring-a"></div>
      <div class="celebration-rings ring-b"></div>
      <div class="celebration-copy">
        <span>Perfect run</span>
        <strong>FULL SYSTEM MASTER</strong>
      </div>
    `;
    document.body.appendChild(overlay);
    timers.add(setTimeout(() => overlay.classList.add('fade'), 1600));
    timers.add(setTimeout(() => overlay.remove(), 2500));
  };

  const flash = (type, text) => {
    const existing = app.querySelector('.flash');
    existing?.remove();
    const node = document.createElement('div');
    node.className = `flash ${type}`;
    node.textContent = text;
    app.prepend(node);
    timers.add(setTimeout(() => node.remove(), 1700));
  };

  const setTerminal = (message) => {
    history.push(String(message));
    if (history.length > 5) history.shift();
    terminal.innerHTML = history.map((line) => `<div class="terminal-line">${TERMINAL_PREFIX} ${escapeHtml(line)}</div>`).join('');
  };

  const bindBoot = ({ onEnableVoice, onStart }) => {
    const enableBtn = document.getElementById('enableVoiceBtn');
    const startBtn = document.getElementById('startBtn');
    const status = document.getElementById('bootStatus');

    enableBtn?.addEventListener('click', async () => {
      enableBtn.disabled = true;
      window.QuizzoraSounds.click();
      status.textContent = 'Voice engine initializing...';
      const rules = [
        'Welcome to Quizzora.',
        'Wrong answers still move you forward.',
        'Only correct answers unlock the next stage.',
        'Your progress resets on refresh.',
        'Complete the full run to unlock the reactor.'
      ];
      await onEnableVoice(rules, () => {
        voiceReady = true;
        startVisible = true;
        startBtn.classList.remove('hidden');
        status.textContent = 'Rules complete. Start Assessment unlocked.';
        setTerminal('VOICE GATE COMPLETE');
      });
    }, { once: true });

    startBtn?.addEventListener('click', async () => {
      if (!startVisible) return;
      window.QuizzoraSounds.click();
      status.textContent = 'Assessment starting...';
      await onStart();
    }, { once: true });
  };

  const questionTypewriter = (node, text, onDone) => {
    const characters = String(text ?? '').split('');
    let i = 0;
    node.textContent = '';
    clearInterval(typeTimer);
    typeTimer = setInterval(() => {
      node.textContent += characters[i] ?? '';
      if (characters[i] && characters[i] !== ' ') window.QuizzoraSounds.typingTick();
      i += 1;
      if (i >= characters.length) {
        clearInterval(typeTimer);
        typeTimer = null;
        onDone?.();
      }
    }, 22);
  };

  const scheduleQuestionReveal = (question, state, total, onAnswer, stage) => {
    clearTimers();
    currentRevealToken += 1;
    const token = currentRevealToken;
    const questionBlock = document.getElementById('questionBlock');
    const questionText = document.getElementById('questionText');
    const optionsNode = document.getElementById('optionsNode');
    const nextLabel = document.getElementById('nextFeatureLabel');

    if (nextLabel) nextLabel.textContent = stage;

    setTerminal(`NODE ${state.currentQuestionIndex + 1} LOADING`);
    window.QuizzoraSounds.transition();

    loaderTimer = setTimeout(() => {
      if (token !== currentRevealToken) return;
      questionBlock?.classList.remove('hidden');
      questionTypewriter(questionText, question.question, () => {
        optionsNode.removeAttribute('aria-busy');
        optionsNode.innerHTML = question.options.map((option) => `
          <button class="option" type="button" data-value="${escapeHtml(option)}">${escapeHtml(option)}</button>
        `).join('');
      });
      optionsNode?.parentElement?.classList.add('live');
      setTerminal(`NODE ${state.currentQuestionIndex + 1} READY`);
    }, 2100);

    app.onclick = (event) => {
      const button = event.target.closest?.('.option');
      if (!button || button.disabled) return;
      window.QuizzoraSounds.click();
      onAnswer(button.dataset.value);
    };
  };

  const setBootState = (value) => {
    startVisible = Boolean(value);
  };

  const resetUI = () => {
    clearTimers();
    app.onclick = null;
    history.length = 0;
  };

  window.QuizzoraUI = {
    bootShell,
    bindBoot,
    renderQuizShell,
    renderResult,
    renderCelebration,
    flash,
    setTerminal,
    setMode,
    setStageFlags,
    normalize,
    escapeHtml,
    resetUI,
    setBootState,
    clearTimers,
  };
})();
