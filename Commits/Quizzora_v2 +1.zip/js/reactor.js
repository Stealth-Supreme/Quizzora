(() => {
  let overlay = null;
  let timers = [];

  const clearTimers = () => {
    timers.forEach((id) => clearTimeout(id));
    timers = [];
  };

  const removeOverlay = () => {
    clearTimers();
    if (overlay?.isConnected) overlay.remove();
    overlay = null;
    document.body.classList.remove('reactor-mode');
  };

  const open = ({ rank = 'SYSTEM ARCHITECT', onDone } = {}) => {
    removeOverlay();
    document.body.classList.add('reactor-mode');
    overlay = document.createElement('div');
    overlay.className = 'reactor-overlay';
    overlay.innerHTML = `
      <div class="reactor-vignette"></div>
      <div class="reactor-shell">
        <div class="reactor-title-block">
          <div class="reactor-kicker">AI CORE ASCENSION</div>
          <div class="reactor-title">HOLOGRAPHIC REACTOR</div>
          <div class="reactor-subtitle">${rank}</div>
        </div>
        <div class="reactor-stage">
          <div class="reactor-rings ring-a"></div>
          <div class="reactor-rings ring-b"></div>
          <div class="reactor-rings ring-c"></div>
          <div class="reactor-core">
            <div class="reactor-core-glow"></div>
            <div class="reactor-core-pulse"></div>
          </div>
          <div class="reactor-panel panel-a"></div>
          <div class="reactor-panel panel-b"></div>
          <div class="reactor-panel panel-c"></div>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);

    window.QuizzoraSounds.reactorHum(true);
    window.QuizzoraSounds.reactorSwell();

    timers.push(setTimeout(() => document.body.classList.add('reactor-intense'), 1100));
    timers.push(setTimeout(() => {
      window.QuizzoraVoice.speak('Full system unlocked. Reactor online.', { rate: 0.9, pitch: 0.94, volume: 1 });
    }, 650));
    timers.push(setTimeout(() => safeDone(onDone), 4600));
  };

  const safeDone = (fn) => {
    try { if (typeof fn === 'function') fn(); } catch {}
  };

  window.QuizzoraReactor = { open, removeOverlay };
})();
