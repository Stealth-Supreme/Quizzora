(() => {
  const layer = document.getElementById('particles');
  let active = false;
  let nodes = [];
  let pulseTimer = null;

  const randomBetween = (min, max) => min + Math.random() * (max - min);

  const createParticle = () => {
    const el = document.createElement('span');
    el.className = 'energy-particle';
    const size = randomBetween(2, 5);
    el.style.left = `${randomBetween(0, 100)}%`;
    el.style.top = `${randomBetween(0, 100)}%`;
    el.style.width = `${size}px`;
    el.style.height = `${size}px`;
    el.style.animationDuration = `${randomBetween(9, 18)}s`;
    el.style.animationDelay = `${randomBetween(0, 8)}s`;
    el.style.setProperty('--x', `${randomBetween(-18, 18)}vw`);
    el.style.setProperty('--y', `${randomBetween(-16, 16)}vh`);
    return el;
  };

  const clear = () => {
    nodes.forEach((node) => node.remove());
    nodes = [];
    active = false;
    if (pulseTimer) clearInterval(pulseTimer);
    pulseTimer = null;
    layer.classList.remove('active');
  };

  const start = (count = 28) => {
    if (!layer) return;
    clear();
    active = true;
    layer.classList.add('active');
    nodes = Array.from({ length: count }, () => createParticle());
    nodes.forEach((node) => layer.appendChild(node));
    pulseTimer = setInterval(() => {
      if (!active) return;
      const p = createParticle();
      layer.appendChild(p);
      nodes.push(p);
      if (nodes.length > count + 10) {
        const removed = nodes.shift();
        removed?.remove();
      }
    }, 900);
  };

  const flash = () => {
    if (!active) return;
    layer.classList.add('pulse');
    setTimeout(() => layer.classList.remove('pulse'), 220);
  };

  window.QuizzoraParticles = { start, clear, flash };
})();
