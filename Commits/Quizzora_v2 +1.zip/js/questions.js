window.QUIZZORA_QUESTIONS = [
  {
    "id": 1,
    "question": "Which of these is location of attach files icon located on the compose windows?",
    "options": [
      "top",
      "left",
      "bottom",
      "right"
    ],
    "accepted": [
      "bottom"
    ],
    "unlock": "theme"
  },
  {
    "id": 2,
    "question": "Which one of these is part of a URL?",
    "options": [
      "Protocol Identifier",
      "Resource name",
      "Domain Name",
      "HTTP"
    ],
    "accepted": [
      "protocol identifier"
    ],
    "unlock": "layout"
  },
  {
    "id": 3,
    "question": "Which one of these is not part of a webpage?",
    "options": [
      "page title",
      "navigation bar",
      "footer",
      "domain name"
    ],
    "accepted": [
      "domain name"
    ],
    "unlock": "shell"
  },
  {
    "id": 4,
    "question": "Which one of these is not a browser?",
    "options": [
      "Firefox",
      "Safari",
      "Google",
      "Opera GX"
    ],
    "accepted": [
      "google"
    ],
    "unlock": "cards"
  },
  {
    "id": 5,
    "question": "Select most common uses of Internet?",
    "options": [
      "Business",
      "Cyber terrorism",
      "Spamming",
      "Google Dorking"
    ],
    "accepted": [
      "business"
    ],
    "unlock": "motion"
  },
  {
    "id": 6,
    "question": "Which of these stores data permanently?",
    "options": [
      "RAM",
      "Hard disk",
      "SSD",
      "Cache"
    ],
    "accepted": [
      "hard disk"
    ],
    "unlock": "hud",
    "note": "Updated to more suitable options."
  },
  {
    "id": 7,
    "question": "Which of these are productive tools offered by G-mail?",
    "options": [
      "instant messages",
      "calendar",
      "calls",
      "none of these"
    ],
    "accepted": [
      "instant messages"
    ],
    "unlock": "terminal-log",
    "note": "Corrected from answer key."
  },
  {
    "id": 8,
    "question": "From which word is the term computer derived from?",
    "options": [
      "Computre",
      "Computare",
      "Compute",
      "None of these"
    ],
    "accepted": [
      "compute"
    ],
    "unlock": "sound"
  },
  {
    "id": 9,
    "question": "What is limit you can send for executable files or messages?",
    "options": [
      "75MB",
      "25MB",
      "50mb",
      "2gb"
    ],
    "accepted": [
      "25mb"
    ],
    "unlock": "scan"
  },
  {
    "id": 10,
    "question": "Which button is used to start writing an email?",
    "options": [
      "Drafts",
      "Calls",
      "Delete messages",
      "Compose"
    ],
    "accepted": [
      "compose"
    ],
    "unlock": "progress"
  },
  {
    "id": 11,
    "question": "______________ enable the global exchange of data, information, and resources between computers, devices, and users",
    "options": [
      "Apps",
      "Data Centre",
      "Communication and networking",
      "Artificial intelligence"
    ],
    "accepted": [
      "communication and networking"
    ],
    "unlock": "question-reveal"
  },
  {
    "id": 12,
    "question": "What is the collection of related web pages containing images, videos, or other digital media set under the same domain name",
    "options": [
      "webpage",
      "Website",
      "search engine",
      "browser"
    ],
    "accepted": [
      "website"
    ],
    "unlock": "feedback"
  },
  {
    "id": 13,
    "question": "What was the name of the account in the g-mail image of books?",
    "options": [
      "Kips World",
      "Kips Publication",
      "Kips Learning",
      "Kips Education"
    ],
    "accepted": [
      "kips learning"
    ],
    "unlock": "results"
  },
  {
    "id": 14,
    "question": "Which app mentioned in book let you edit text?",
    "options": [
      "Wordpad",
      "Notepad",
      "Google Docs",
      "Ms Word"
    ],
    "accepted": [
      "wordpad"
    ],
    "unlock": "badge"
  },
  {
    "id": 15,
    "question": "Who wrote the quote in this chapter?",
    "options": [
      "Blake Lively",
      "Satya Nadella",
      "Bill Gates",
      "Richard Branson"
    ],
    "accepted": [
      "richard branson"
    ],
    "unlock": "polish"
  },
  {
    "id": 16,
    "question": "How many friends does the gmail account in the book have?",
    "options": [
      "0",
      "1",
      "2-5",
      "5+"
    ],
    "accepted": [
      "0"
    ],
    "unlock": "celebration"
  },
  {
    "id": 17,
    "question": "How many mails has the person sent?",
    "options": [
      "0",
      "1",
      "2-5",
      "5+"
    ],
    "accepted": [
      "1"
    ],
    "unlock": "extended"
  },
  {
    "id": 18,
    "question": "When was this screenshot taken?",
    "options": [
      "12 June",
      "12 May",
      "27 June",
      "27 May"
    ],
    "accepted": [
      "12 june"
    ],
    "unlock": "scan-lines"
  },
  {
    "id": 19,
    "question": "How many E-mails were mentioned in the book?",
    "options": [
      "1",
      "2",
      "3-5",
      "5+"
    ],
    "accepted": [
      "2"
    ],
    "unlock": "ranking"
  },
  {
    "id": 20,
    "question": "In which chapter do we learn about input and output device?",
    "options": [
      "1",
      "2",
      "9",
      "10"
    ],
    "accepted": [
      "9"
    ],
    "unlock": "ending"
  }
];
