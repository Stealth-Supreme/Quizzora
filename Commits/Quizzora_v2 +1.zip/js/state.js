(() => {
  const createState = () => ({
    started: false,
    currentQuestionIndex: 0,
    score: 0,
    failedAny: false,
    completed: false,
    unlockedStages: [],
    answeredQuestions: [],
    perfectRun: false,
  });

  const clone = (value) => JSON.parse(JSON.stringify(value));
  const fresh = () => clone(createState());

  window.QuizzoraState = {
    fresh,
    createState,
    clone,
  };
})();
