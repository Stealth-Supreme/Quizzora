(() => {
  const synth = window.speechSynthesis || null;
  let voice = null;
  let ready = false;
  let queue = Promise.resolve();

  const pickVoice = () => {
    if (!synth) return null;
    const voices = synth.getVoices() || [];
    voice = voices.find((v) => /en/i.test(v.lang) && /female/i.test(v.name))
      || voices.find((v) => /en/i.test(v.lang))
      || voices[0]
      || null;
    ready = true;
    return voice;
  };

  if (synth) {
    synth.onvoiceschanged = pickVoice;
    pickVoice();
  }

  const safeCallback = (fn) => {
    try { if (typeof fn === 'function') fn(); } catch {}
  };

  const speakOnce = (text, options = {}) => new Promise((resolve) => {
    const message = String(text ?? '').trim();
    if (!synth || !('SpeechSynthesisUtterance' in window) || !message) {
      safeCallback(options.onEnd);
      resolve('fallback');
      return;
    }

    try {
      synth.cancel();
      if (!ready) pickVoice();
      const utter = new SpeechSynthesisUtterance(message);
      utter.lang = options.lang || 'en-US';
      utter.rate = Number.isFinite(options.rate) ? options.rate : 1;
      utter.pitch = Number.isFinite(options.pitch) ? options.pitch : 1;
      utter.volume = Number.isFinite(options.volume) ? options.volume : 1;
      if (voice) utter.voice = voice;
      utter.onend = () => {
        safeCallback(options.onEnd);
        resolve('ended');
      };
      utter.onerror = () => {
        safeCallback(options.onError);
        safeCallback(options.onEnd);
        resolve('error');
      };
      synth.speak(utter);
    } catch {
      safeCallback(options.onError);
      safeCallback(options.onEnd);
      resolve('error');
    }
  });

  const speak = (text, options = {}) => {
    queue = queue.then(() => speakOnce(text, options));
    return queue;
  };

  const speakLines = async (lines = [], options = {}) => {
    for (const line of lines) {
      await speak(line, options);
      await new Promise((resolve) => setTimeout(resolve, options.pauseMs || 120));
    }
  };

  const stop = () => {
    if (synth) synth.cancel();
  };

  window.QuizzoraVoice = { speak, speakLines, stop, pickVoice };
})();
