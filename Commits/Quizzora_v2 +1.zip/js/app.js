
(() => {
  const questions = window.QUIZZORA_QUESTIONS || [];
  const total = questions.length;

  const featureOrder = [
    'theme', 'layout', 'shell', 'cards', 'motion', 'hud', 'audio', 'scan', 'progress',
    'reveal', 'feedback', 'results', 'badges', 'celebration', 'particles', 'polish',
    'ranking', 'extended', 'reactor'
  ];

  const featureTitles = {
    theme: 'Theme',
    layout: 'Layout',
    shell: 'Shell',
    cards: 'Cards',
    motion: 'Motion',
    hud: 'HUD',
    audio: 'Audio',
    scan: 'Scan',
    progress: 'Progress',
    reveal: 'Reveal',
    feedback: 'Feedback',
    results: 'Results',
    badges: 'Badges',
    celebration: 'Celebration',
    particles: 'Particles',
    polish: 'Polish',
    ranking: 'Ranking',
    extended: 'Extended HUD',
    reactor: 'Reactor',
  };

  const baseStyles = new Map([
    ['theme', './css/theme.css'],
    ['layout', './css/layout.css'],
    ['shell', './css/shell.css'],
    ['terminal', './css/terminal.css'],
  ]);

  const stageStyles = {
    quiz: ['cards', 'motion', 'hud', 'scan', 'reveal', 'feedback'],
    results: ['results', 'badges'],
    celebration: ['celebration'],
    particles: ['particles'],
    reactor: ['reactor'],
  };

  const stageForFeature = {
    theme: null,
    layout: null,
    shell: null,
    cards: 'quiz',
    motion: 'quiz',
    hud: 'quiz',
    audio: 'quiz',
    scan: 'quiz',
    progress: 'quiz',
    reveal: 'quiz',
    feedback: 'quiz',
    results: 'results',
    badges: 'results',
    celebration: 'celebration',
    particles: 'particles',
    polish: 'quiz',
    ranking: 'results',
    extended: 'quiz',
    reactor: 'reactor',
  };

  const terminal = (text) => window.QuizzoraUI.setTerminal(text);
  const state = window.QuizzoraState.fresh();
  const loaded = new Set();
  const loadPromises = new Map();

  const currentQuestion = () => questions[state.currentQuestionIndex] || null;
  const nextPendingFeature = () => featureOrder[state.unlockedStages.length] || 'reactor';
  const nextPendingLabel = () => featureTitles[nextPendingFeature()] || 'Standby';

  const ensureStyle = (key) => {
    if (!key) return Promise.resolve(false);
    if (loaded.has(key)) return Promise.resolve(true);
    if (loadPromises.has(key)) return loadPromises.get(key);

    const existing = document.querySelector(`link[data-quizzora-style="${key}"]`);
    if (existing) {
      loaded.add(key);
      return Promise.resolve(true);
    }

    const href = baseStyles.get(key);
    if (!href) return Promise.resolve(false);

    const promise = new Promise((resolve) => {
      const link = document.createElement('link');
      link.rel = 'stylesheet';
      link.href = href;
      link.dataset.quizzoraStyle = key;
      link.onload = () => {
        loaded.add(key);
        resolve(true);
      };
      link.onerror = () => resolve(false);
      document.head.appendChild(link);
    });

    loadPromises.set(key, promise);
    return promise.finally(() => loadPromises.delete(key));
  };

  const ensureStyles = async (keys = []) => {
    const unique = [...new Set(keys.filter(Boolean))];
    await Promise.all(unique.map((key) => ensureStyle(key)));
  };

  const ensureFeatureStyles = async (feature) => {
    const stage = stageForFeature[feature];
    if (stage && stageStyles[stage]) {
      await ensureStyles(stageStyles[stage]);
    }
  };

  const unlockNextStage = async () => {
    const nextStage = featureOrder[state.unlockedStages.length];
    if (!nextStage) return null;
    if (state.unlockedStages.includes(nextStage)) return nextStage;

    await ensureFeatureStyles(nextStage);
    state.unlockedStages.push(nextStage);
    document.body.classList.add(`feature-${nextStage}`);
    document.body.dataset.unlocked = state.unlockedStages.join(' ');
    window.QuizzoraSounds.unlock();
    window.QuizzoraParticles.flash();
    if (nextStage === 'particles' || nextStage === 'micro') window.QuizzoraParticles.start(34);
    if (nextStage === 'reactor') document.body.classList.add('feature-reactor');
    terminal(`FEATURE UNLOCKED | ${featureTitles[nextStage]}`);
    return nextStage;
  };

  const buildProfile = () => {
    const accuracy = total ? Math.round((state.score / total) * 100) : 0;
    const perfect = !state.failedAny && state.score === total;
    const badges = [];

    if (state.score >= 1) badges.push('FIRST NODE');
    if (state.score >= Math.ceil(total * 0.5)) badges.push('MIDWAY CONTROL');
    if (accuracy >= 75) badges.push('STABLE HAND');
    if (accuracy >= 90) badges.push('ELITE OPERATOR');
    if (perfect) badges.push('FULL SYSTEM MASTER');

    if (perfect) {
      return {
        complete: true,
        rank: 'SYSTEM ARCHITECT',
        badge: 'FULL UNLOCK',
        summary: 'AI core ascension complete. Reactor interface is live.',
        accuracy,
        badges,
        profileLine: 'MASTER',
      };
    }
    if (accuracy >= 90) {
      return {
        complete: false,
        rank: 'STRATEGIC THINKER',
        badge: 'NEAR MASTER',
        summary: 'Strong run, but one wrong answer blocks the full build.',
        accuracy,
        badges,
        profileLine: 'ALMOST',
      };
    }
    if (accuracy >= 70) {
      return {
        complete: false,
        rank: 'ADVANCED OPERATOR',
        badge: 'PARTIAL UNLOCK',
        summary: 'Good control, but the system stayed partially locked.',
        accuracy,
        badges,
        profileLine: 'PARTIAL',
      };
    }
    return {
      complete: false,
      rank: 'NOVICE OPERATOR',
      badge: 'LOCKED',
      summary: 'The build remains constrained.',
      accuracy,
      badges,
      profileLine: 'LOCKED',
    };
  };

  const goToResult = async () => {
    state.completed = true;
    await ensureStyles(stageStyles.results);
    const profile = buildProfile();
    window.QuizzoraUI.renderResult({ state, total, profile, onRestart: restart });
    terminal(`ASSESSMENT COMPLETE | SCORE ${state.score}/${total}`);
    if (profile.complete) {
      await ensureStyles([...stageStyles.celebration, ...stageStyles.reactor, ...stageStyles.particles]);
      window.QuizzoraUI.renderCelebration();
      window.QuizzoraSounds.success();
      setTimeout(() => {
        window.QuizzoraReactor.open({ rank: profile.rank, onDone: () => terminal('REACTOR SEQUENCE COMPLETE') });
      }, 1500);
    } else {
      window.QuizzoraSounds.failure();
      window.QuizzoraVoice.speak('Complete website not unlocked.', { rate: 0.92, pitch: 0.94, volume: 1 });
    }
  };

  const advance = () => {
    state.currentQuestionIndex += 1;
    if (state.currentQuestionIndex >= total) {
      void goToResult();
      return;
    }
    renderQuestion();
  };

  const submitAnswer = async (value) => {
    const question = currentQuestion();
    if (!question) return;

    const selected = window.QuizzoraUI.normalize(value);
    const accepted = (question.accepted || []).map(window.QuizzoraUI.normalize);
    const correct = accepted.includes(selected);
    const optionButtons = document.querySelectorAll('.option');

    optionButtons.forEach((button) => {
      button.disabled = true;
      if (window.QuizzoraUI.normalize(button.dataset.value) === selected) {
        button.classList.add(correct ? 'correct' : 'wrong');
      }
    });

    if (correct) {
      state.score += 1;
      const unlocked = await unlockNextStage();
      const unlockedLabel = featureTitles[unlocked] || nextPendingLabel();
      const msg = `Correct answer, ${unlockedLabel} unlocked.`;
      window.QuizzoraUI.flash('good', msg);
      terminal(`CORRECT | ${msg}`);
      window.QuizzoraSounds.success();
      window.QuizzoraVoice.speak(msg, { rate: 1.0 });
    } else {
      state.failedAny = true;
      const msg = `Wrong answer, unable to unlock ${nextPendingLabel().toLowerCase()}.`;
      window.QuizzoraUI.flash('bad', msg);
      terminal(`WRONG | ${msg}`);
      window.QuizzoraSounds.failure();
      window.QuizzoraVoice.speak(msg, { rate: 0.95 });
    }

    setTimeout(advance, 2100);
  };

  const renderQuestion = () => {
    const question = currentQuestion();
    if (!question) {
      void goToResult();
      return;
    }
    window.QuizzoraUI.setStageFlags(state.unlockedStages);
    window.QuizzoraUI.renderQuizShell({
      state,
      total,
      question,
      unlockLabel: nextPendingLabel(),
      onAnswer: submitAnswer,
    });
    terminal(`NODE ${state.currentQuestionIndex + 1} LOADING`);
  };

  const startQuiz = async () => {
    state.started = true;
    await ensureStyles(stageStyles.quiz);
    window.QuizzoraSounds.ambient(true);
    window.QuizzoraSounds.boot();
    terminal('LAUNCH SEQUENCE STARTED');
    renderQuestion();
    window.QuizzoraVoice.speak('Launching quiz interface.', { rate: 0.96 });
  };

  const reset = () => {
    window.QuizzoraVoice.stop();
    window.QuizzoraSounds.ambient(false);
    window.QuizzoraSounds.reactorHum(false);
    window.QuizzoraParticles.clear();
    window.QuizzoraReactor.removeOverlay();
    window.QuizzoraUI.resetUI();
    document.querySelectorAll('link[data-quizzora-style]').forEach((link) => {
      const key = link.dataset.quizzoraStyle;
      if (!baseStyles.has(key)) {
        link.remove();
        loaded.delete(key);
      }
    });
    Object.assign(state, window.QuizzoraState.fresh());
    document.body.className = '';
    document.body.dataset.mode = 'boot';
    document.body.dataset.unlocked = '';
    boot();
  };

  const enableVoice = async (rules, onDone) => {
    if (window.QuizzoraVoice?.speakLines) {
      await window.QuizzoraVoice.speakLines(rules, { rate: 0.96, pauseMs: 130 });
    } else {
      await new Promise((resolve) => setTimeout(resolve, 900));
    }
    onDone?.();
  };

  const boot = () => {
    window.QuizzoraUI.bootShell();
    window.QuizzoraUI.setTerminal('SYSTEM READY');
    window.QuizzoraUI.bindBoot({
      onEnableVoice: enableVoice,
      onStart: startQuiz,
    });
    if (total === 0) {
      window.QuizzoraUI.setTerminal('NO QUESTIONS LOADED');
    }
  };

  window.addEventListener('quiz:restart', reset);
  boot();
})();
